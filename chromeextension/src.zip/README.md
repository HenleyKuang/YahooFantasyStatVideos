# Envs

Tested on a gnome linux environment

# Versions

```
$ node --version
v16.4.2
$ npm --version
7.18.1
```

# Build Chrome Extension

```
make build
```

# Build Firefox AddOn

```
make build-firefox
```